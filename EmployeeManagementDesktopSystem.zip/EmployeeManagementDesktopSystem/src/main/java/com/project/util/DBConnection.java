package com.project.util;

import java.sql.*;

public class DBConnection {
    private static final String DB_URL = "jdbc:derby://localhost:1527/EmployeeDB;create=true";
    private static final String USER = "app";
    private static final String PASS = "app";

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, USER, PASS);
    }
}
