package com.project.ui;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.*;
import com.project.model.Employee;
import com.project.dao.EmployeeDAO;
import java.util.List;


public class EmployeeForm extends javax.swing.JFrame {
    
    
    private JTextField nameField, idField, departmentField;
    private JFormattedTextField salaryField;
    private JButton addButton, updateButton, deleteButton, clearButton, exportButton;
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    private EmployeeDAO employeeDAO;

    public EmployeeForm() {
        employeeDAO = new EmployeeDAO();
        setTitle("Employee Management System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(850, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        initUI();
        loadEmployees();
        setVisible(true);
    }

    private void initUI() {
        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBorder(BorderFactory.createTitledBorder("Employee Details"));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.WEST;

        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Full Name:"), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(20);
        formPanel.add(nameField, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Employee ID:"), gbc);
        gbc.gridx = 1;
        idField = new JTextField(20);
        formPanel.add(idField, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Department:"), gbc);
        gbc.gridx = 1;
        departmentField = new JTextField(20);
        formPanel.add(departmentField, gbc);

        gbc.gridx = 0; gbc.gridy = 3;
        formPanel.add(new JLabel("Salary:"), gbc);
        gbc.gridx = 1;
        salaryField = new JFormattedTextField();
        salaryField.setColumns(20);
        formPanel.add(salaryField, gbc);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 15, 5));
        addButton = new JButton("Add");
        updateButton = new JButton("Update");
        deleteButton = new JButton("Delete");
        clearButton = new JButton("Clear");
        exportButton = new JButton("Export CSV");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);
        buttonPanel.add(exportButton);

        addButton.addActionListener(this::handleAdd);
        updateButton.addActionListener(this::handleUpdate);
        deleteButton.addActionListener(this::handleDelete);
        clearButton.addActionListener(e -> clearFields());
        exportButton.addActionListener(e -> exportTableToCSV());

        String[] columnNames = {"ID", "Name", "Department", "Salary"};
        tableModel = new DefaultTableModel(columnNames, 0);
        employeeTable = new JTable(tableModel);
        employeeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        employeeTable.getSelectionModel().addListSelectionListener(e -> loadSelectedEmployee());

        JScrollPane tableScroll = new JScrollPane(employeeTable);
        tableScroll.setBorder(BorderFactory.createTitledBorder("Employee Records"));

        add(formPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.CENTER);
        add(tableScroll, BorderLayout.SOUTH);
    }

    private boolean validateFields() {
        if (idField.getText().trim().isEmpty() ||
            nameField.getText().trim().isEmpty() ||
            departmentField.getText().trim().isEmpty() ||
            salaryField.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill out all fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        try {
            Double.parseDouble(salaryField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Salary must be a number.", "Validation Error", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void handleAdd(ActionEvent e) {
        if (!validateFields()) return;
        try {
            String id = idField.getText();
            String name = nameField.getText();
            String dept = departmentField.getText();
            double salary = Double.parseDouble(salaryField.getText());

            Employee emp = new Employee(id, name, dept, salary);
            employeeDAO.addEmployee(emp);
            loadEmployees();
            clearFields();
            JOptionPane.showMessageDialog(this, "Employee added successfully.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void handleUpdate(ActionEvent e) {
        if (!validateFields()) return;
        try {
            String id = idField.getText();
            String name = nameField.getText();
            String dept = departmentField.getText();
            double salary = Double.parseDouble(salaryField.getText());

            Employee emp = new Employee(id, name, dept, salary);
            employeeDAO.updateEmployee(emp);
            loadEmployees();
            clearFields();
            JOptionPane.showMessageDialog(this, "Employee updated successfully.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void handleDelete(ActionEvent e) {
        try {
            String id = idField.getText();
            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select an employee to delete.");
                return;
            }
            employeeDAO.deleteEmployee(id);
            loadEmployees();
            clearFields();
            JOptionPane.showMessageDialog(this, "Employee deleted successfully.");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error: " + ex.getMessage());
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        departmentField.setText("");
        salaryField.setText("");
        employeeTable.clearSelection();
    }

    private void loadEmployees() {
        try {
            tableModel.setRowCount(0);
            List<Employee> employees = employeeDAO.getAllEmployees();
            for (Employee emp : employees) {
                tableModel.addRow(new Object[]{emp.getId(), emp.getName(), emp.getDepartment(), emp.getSalary()});
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Failed to load employees.");
        }
    }

    private void loadSelectedEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow >= 0) {
            idField.setText(tableModel.getValueAt(selectedRow, 0).toString());
            nameField.setText(tableModel.getValueAt(selectedRow, 1).toString());
            departmentField.setText(tableModel.getValueAt(selectedRow, 2).toString());
            salaryField.setText(tableModel.getValueAt(selectedRow, 3).toString());
        }
    }

    private void exportTableToCSV() {
        try (FileWriter fw = new FileWriter("employees.csv")) {
            for (int i = 0; i < tableModel.getColumnCount(); i++) {
                fw.write(tableModel.getColumnName(i) + (i < tableModel.getColumnCount() - 1 ? "," : "\n"));
            }
            for (int row = 0; row < tableModel.getRowCount(); row++) {
                for (int col = 0; col < tableModel.getColumnCount(); col++) {
                    fw.write(tableModel.getValueAt(row, col).toString() + (col < tableModel.getColumnCount() - 1 ? "," : "\n"));
                }
            }
            JOptionPane.showMessageDialog(this, "Data exported to employees.csv");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error exporting to CSV: " + e.getMessage());
        }
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public static void main(String args[]) {
       try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> new EmployeeForm());
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
