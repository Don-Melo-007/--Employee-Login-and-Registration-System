package com.project.dao;

import com.project.model.Employee;
import com.project.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    public void addEmployee(Employee emp) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("INSERT INTO Employee VALUES (?, ?, ?, ?)");
        ps.setString(1, emp.getId());
        ps.setString(2, emp.getName());
        ps.setString(3, emp.getDepartment());
        ps.setDouble(4, emp.getSalary());
        ps.executeUpdate();
        conn.close();
    }

    public List<Employee> getAllEmployees() throws SQLException {
        Connection conn = DBConnection.getConnection();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM Employee");

        List<Employee> list = new ArrayList<>();
        while (rs.next()) {
            Employee emp = new Employee(
                rs.getString("id"),
                rs.getString("name"),
                rs.getString("department"),
                rs.getDouble("salary")
            );
            list.add(emp);
        }
        conn.close();
        return list;
    }

    public void updateEmployee(Employee emp) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("UPDATE Employee SET name=?, department=?, salary=? WHERE id=?");
        ps.setString(1, emp.getName());
        ps.setString(2, emp.getDepartment());
        ps.setDouble(3, emp.getSalary());
        ps.setString(4, emp.getId());
        ps.executeUpdate();
        conn.close();
    }

    public void deleteEmployee(String id) throws SQLException {
        Connection conn = DBConnection.getConnection();
        PreparedStatement ps = conn.prepareStatement("DELETE FROM Employee WHERE id=?");
        ps.setString(1, id);
        ps.executeUpdate();
        conn.close();
    }
}
